import{s}from"../chunks/scheduler.e108d1fd.js";import{S as t,i as e}from"../chunks/index.7cf2deec.js";class r extends t{constructor(o){super(),e(this,o,null,null,s,{})}}export{r as component};
